
http://magazines-australia.com/

https://a2nwvpweb010.shr.prod.iad2.secureserver.net:8443/login_up.php3
MagAustralia
Jaishreer@m98

Db_name:- MagAustralia_1
Db_Uname:- MagAustralia
DB_password:- Yspg8$32

http://magazines-australia.com/
user: MagAustralia
pass: yKj28t#4


old ip:- 50.63.202.47